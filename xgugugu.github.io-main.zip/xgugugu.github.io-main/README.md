# 个人网站

## 介绍

网址：<https://xgugugu.github.io/>

这是我首次尝试写SPA的单页网站

作为一位不会用vue的蒟蒻，只好用jquery手搓响应式了（其实jquery的链式函数调用还是挺好用的）

由于没有用虚拟DOM树，所以在浏览器拓展比较多（或者电脑性能比较差）的情况下可能会有些卡顿

网页源代码基于GPLv2许可证开源

### 旧版

曾经的 [xgugugu/home](https://github.com/xgugugu/home) 和 [xgugugu/blog](https://github.com/xgugugu/blog) 的网页代码已全部移至 [old](https://github.com/xgugugu/xgugugu.github.io/tree/main/old) 目录

### 分支

不论是否fork本仓库，所有使用本仓库代码（包括旧版）的仓库及其分支均被视为本仓库代码的分支

目前已知的分支有：

- [BaoSiYuanCODE/BaoSiYuanCODE.github.io](https://github.com/BaoSiYuanCODE/BaoSiYuanCODE.github.io)

- [WP-Studio01/freedom](https://github.com/WP-Studio01/freedom)

  - [codejiangqihan/freedom](https://github.com/codejiangqihan/freedom)

- [WP-Studio01/home](https://github.com/WP-Studio01/home)

- [WP-Studio01/blog](https://github.com/WP-Studio01/blog)
